/*
 * SWD_pgm.c
 *
 *  Created on: Mar 19, 2021
 *      Author: hello
 */

#include "main.h"
#include "SWD_host.h"
#include "SWD_flash.h"
#include "fops.h"
#include "DAP_config.h"
#include "flash_blob.h"
#include "stdio.h"
#include "ctype.h"
#include "DAP.h"
#include "SWD_pgm.h"
#include "jsmn.h"

uint8_t g_FlashErasingFlag = 0;

#define SWD_PACKET_SIZE (1024U)

uint8_t SWD_PACKET_BUF[SWD_PACKET_SIZE];

/**
 * 十六进制字符转十六进制数，例：'A' -> 0xA
 * @param  chr 要转换的十六进制字符
 * @return     转换后的值
 */
uint8_t chr2hex(uint8_t chr)
{
	if (chr >= '0' && chr <= '9')return chr - '0';
	if (chr >= 'A' && chr <= 'F')return (chr - 'A' + 10);
	if (chr >= 'a' && chr <= 'f')return (chr - 'a' + 10);
	return 0;
}

/**
 * 十六进制字符串转数值，例："AABBCC" -> 0XAA,0XBB,0XCC
 * @param str 待转换的十六进制字符串
 * @param len 字符串长度
 * @param hex 存放转换后的字符串值
 */
void str2hex(const void* str, int len, uint8_t* hex)
{
	const uint8_t* s = (const uint8_t *)str;
	uint8_t* d = (uint8_t *)hex;

	if(len % 2 != 0)
	{
		*d = chr2hex(s[0]);
		d += 1;
		s += 1;
		len -= 1;
	}

	while (len > 0)
	{
		*d = (chr2hex(s[0]) << 4) | chr2hex(s[1]);
		d += 1;
		s += 2;
		len -= 2;
	}
}

#define JSON_TOKENS  32

jsmn_parser parser;

jsmntok_t json_tokens[JSON_TOKENS]; /* We expect no more than 32 JSON tokens */

int GetCfgInfo(char* appname, int* flash_algo_index)
{
	int i = 0, k = 0;
	int len = 0;
	int count = 0;
	int flag = 0;
	char* json_string = (char *)&SWD_PACKET_BUF[0];
	char mcutype[64];

	appname[0] = 0;
	*flash_algo_index = -1;

	if(exf_open("config.json", FA_READ) != FR_OK)
	{
		return -1;
	}
	
	if((count = exf_read(json_string, 1024)) <= 0)
	{
		exf_close();
		return -2;
	}

	exf_close();
	
	json_string[count] = 0;
	
	jsmn_init(&parser);

	count = jsmn_parse(&parser, json_string, strlen(json_string), json_tokens, JSON_TOKENS);
	
	if(count <= 1 || json_tokens[0].type != JSMN_OBJECT)
	{
		return -3;
	}
	
	for(i = 1; i < count; i++)
	{
		if(strncmp("firmware", &json_string[json_tokens[i].start], 8) == 0)
		{
			flag++;
			i++;
			len = json_tokens[i].end - json_tokens[i].start;
			memcpy(appname, &json_string[json_tokens[i].start], len);
			appname[len] = 0;
		}
		
		if(strncmp("mcutype", &json_string[json_tokens[i].start], 7) == 0)
		{
			flag++;
			i++;
			len = json_tokens[i].end - json_tokens[i].start;
			memcpy(mcutype, &json_string[json_tokens[i].start], len);
			mcutype[len] = 0;
			
			for(k = 0; k < sizeof(g_FlashAlog.table)/sizeof(g_FlashAlog.table[0]); k++)
			{
				if(strncmp(mcutype, g_FlashAlog.table[k].name, strlen(g_FlashAlog.table[k].name)) == 0)
				{
					*flash_algo_index = k;
					break;
				}
			}
		}
		
		if(flag == 2)
		{
			break;
		}
	}
	
	if(*flash_algo_index < 0)
	{
		return -4;
	}

	return 0;
}

int SWD_BinProgram(void)
{
	int onoff = 0;
	int ret = 0;
	int nread = 0;
	int nwrite = 0;
	int fsize = 0;
	uint32_t addr = 0X08000000;
	char appname[64];
	uint8_t* buf = &SWD_PACKET_BUF[0];

	LED_CONNECTED_OUT(0);
	LED_RUNNING_OUT(0);

	// 获取配置文件信息
	if(GetCfgInfo(appname, &g_FlashAlog.index) != 0)
	{
		ret = -1;
		goto __exit;
	}

	// 打开固件文件
	if ((ret = exf_open(appname, FA_READ)) != FR_OK)
	{
		ret = -2;
		goto __exit;
	}

	// 初始化目标MCU进入debug模式
	if(!swd_init_debug())
	{
		ret = -3;
		goto __exit;
	}

	// 将FLASH编程算法下载进目标MCU
	if(target_flash_init(addr) != ERROR_SUCCESS)
	{
		ret = -4;
		goto __exit;
	}

	// 擦除目标MCU
	g_FlashErasingFlag = 1;
	if(target_flash_erase_chip() != ERROR_SUCCESS)
	{
		g_FlashErasingFlag = 0;
		ret = -5;
		goto __exit;
	}
	g_FlashErasingFlag = 0;
	LED_RUNNING_OUT(1);  // 擦除完毕后红灯常亮提示已经擦除完成

	// 获取新固件文件大小
	fsize = exf_get_open_file_size();

	// 写入新固件
	while (fsize > 0)
	{
		if ((nread = exf_read(buf, SWD_PACKET_SIZE)) < 0)  // 从固件文件中读取1K
		{
			ret = -6;
			goto __exit;
		}

		if (target_flash_program_page(addr, buf, SWD_PACKET_SIZE) != ERROR_SUCCESS)  // 写入目标MCU
		{
			ret = -7;
			goto __exit;
		}

		addr += SWD_PACKET_SIZE;
		fsize -= nread;
		nwrite += nread;
		LED_CONNECTED_OUT(onoff);  // 绿色LED灯闪烁提示正在下载
		onoff = !onoff;
	}
	LED_CONNECTED_OUT(1);          // 下载完成后绿灯常亮提示已经下载完成

	// 重新初始化目标MCU并进入debug模式
	if(!swd_init_debug())
	{
		ret = -8;
		goto __exit;
	}

	// 复位目标MCU并运行新程序
	swd_set_target_reset(0); 

	// 两个LED灯双闪两下提示下载完成
	LED_CONNECTED_OUT(0);
	LED_RUNNING_OUT(0);
	HAL_Delay(100);
	LED_CONNECTED_OUT(1);
	LED_RUNNING_OUT(1);
	HAL_Delay(100);
	LED_CONNECTED_OUT(0);
	LED_RUNNING_OUT(0);
	HAL_Delay(100);
	LED_CONNECTED_OUT(1);
	LED_RUNNING_OUT(1);
	HAL_Delay(300);
	LED_CONNECTED_OUT(0);
	LED_RUNNING_OUT(0);

__exit:
	if(ret != 0)
	{
		// 红色LEDD灯闪两下用于提示下载失败
		LED_CONNECTED_OUT(0);
		LED_RUNNING_OUT(1);
		HAL_Delay(50U);
		LED_RUNNING_OUT(0);
		HAL_Delay(50U);
		LED_RUNNING_OUT(1);
		HAL_Delay(50U);
		LED_RUNNING_OUT(0);
		HAL_Delay(50U);
		LED_RUNNING_OUT(1);
		HAL_Delay(50U);
		LED_RUNNING_OUT(0);
	}
	exf_close();
	return ret;
}

/*
 * SWD_pgm.h
 *
 *  Created on: Mar 19, 2021
 *      Author: hello
 */

#ifndef INC_SWD_PGM_H_
#define INC_SWD_PGM_H_

int SWD_BinProgram(void);

#endif /* INC_SWD_PGM_H_ */
